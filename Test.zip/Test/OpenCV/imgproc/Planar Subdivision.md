
```cpp
class Subdiv2D(){

}
```