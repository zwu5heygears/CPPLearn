```cpp
cvtColor(src, src, COLOR_BGR2Luv); 
```


---

```cpp
cvtColorTwoPlane(); // YUV2BGR(A);
```


---
```cpp
demosaicing(src, src, COLOR_BayerGB2BGR);   // input:Bayer
```