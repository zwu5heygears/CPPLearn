

```cpp

applyColorMap(src, src, COLORMAP_JET);
```