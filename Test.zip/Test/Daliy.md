10.7
编译paddleocr C++库运行在linux服务端
10.8
RK3399 paddle lite 部署方案
复习巩固
提供linux C++ paddleocr接口
10.9
复习线程池 线程安全 设计模式等知识并在分享会上分享
10.10
1. 框架整理
2. 