- Computer Language
1. [[C++]]
2. [[Python]]
3. Golang
4. Rust
5. JavaScript
6. Lua
- Computer Skills
1. Multi threading
2. [[CUDA]]/OpenCL
3. STL
4. FFI
5. Cross platform Windows/Linux
6. API Standard
7. [[Git]]
- Library
1. OpenCV
2. [[NPP]]
3. OpenGL
4. OpenMesh
5. Open3D
6. [[OSG]]
7. [[QT]]
- DL Algorithm
8. [[NeRF]]
9. NeuS
10. SLAM
11. SFM
- DL Frame
12. Pytroch
13. Pytroch3D
14. Tensorflow
15. Jax
16. TensorRT
- SoftWare
17. UE4
18. Unity
19. Blender
20. Maya
21. 3DSMAX
22. Carla
23. AirSim
24. Meshroom
25. COLMAP
26. CGAL
27. libigl
- Other
28. Kaggle
29. LetCode
- Direction
30. Embedded inmplementation and acceleration of perception algorithms
31. Optimize framework tranning speed, including computation/communication/scheduling
32. 3D Object Detection/3D Semantic Sementation/3D Scene Reconstruction/3D Completion/3D Key Point Detection
33. Gaze Estimation/Head Pose Estimation


---
分形三维：webGL服务提供商（先临openGL ES）