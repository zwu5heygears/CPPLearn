六大组件
容器 Container
适配器 Adapter
算法 Algorithm
迭代器 Iterator
仿函数 
分配器

# Vector
