NVIDIA 2D Image and Signal Performance Primitives
用于执行CUDA加速2D图像处理的函数库（GPU编译版的OpenCV）
