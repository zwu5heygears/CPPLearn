#  <font color = #8B6CEF size = 5>Hardware</font>
## DLP
- TI DLP4500 日本茉莉特 MORITEX 代理商：东莞某视觉公司
>DLP芯片DMD只有德州仪器Texas Instruments (TI) 可以提供 
## 相机

## 远心镜头
- 重庆公司代理定制 40w左右

 # 八段光源
 垂直光+同轴光+RGBY

设计资料：

## 控制卡
使用外触发同步控制八段光源和相机、投影仪
# <font color = #8B6CEF size = 5>Software</font>
## 相机标定
- 圆形棋盘格 7x8张 双目带特征点的标定板
- 远心相机
圆形标定板比棋盘格好的原因：https://blog.csdn.net/vivo01/article/details/128477610




## 投影仪标定



## 三维重建
C++ / Python

## 系统平台
QT为主界面 OPencv处理
## 检测方案
制作模板+ROI区域检测
