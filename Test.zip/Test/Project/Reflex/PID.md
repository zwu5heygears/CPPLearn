
<font size = 6>$\mu (t) = K_p e(t) + K_I\int^t _0 e(t)dt + K_D\frac{de(t)}{dt}$  </font>

Reference: https://github.com/tekdemo/MiniPID.git

https://www.zhihu.com/question/402289932/answer/3090892219?utm_id=0
```cpp
https://github.com/tekdemo/MiniPID.git
```

# 离散简易PID
![[Pasted image 20230901174750.png]]